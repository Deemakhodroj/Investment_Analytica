import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:investment_analatyca_testthree/models/user_model.dart';
import 'package:mock_data/mock_data.dart';

class MovementAVG extends StatefulWidget {
  const MovementAVG({Key? key}) : super(key: key);

  @override
  State<MovementAVG> createState() => _MovementAVGState();
}

class _MovementAVGState extends State<MovementAVG> {
  @override
  User? user = FirebaseAuth.instance.currentUser;
  UserModel loggedInUser = UserModel();
  @override
  void initState() {
    super.initState();
    FirebaseFirestore.instance
        .collection("users")
        .doc(user!.uid)
        .get()
        .then((value) {
      loggedInUser = UserModel.fromMap(value.data());
      setState(() {});
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.fromLTRB(10, 65, 10, 10),
        child: Column(
          //crossAxisAlignment: CrossAxisAlignment.baseline,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    Row(
                      children: const [
                        Text(
                          'Welcome back',
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.black54,
                          ),
                        ),
                        SizedBox(
                          width: 60,
                        )
                      ],
                    ),
                    Text(
                      '${loggedInUser.firstName} ${loggedInUser.lastName}',
                      style: const TextStyle(
                        fontSize: 30,
                        color: const Color(0XFF010000),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  width: 10,
                ),
                const CircleAvatar(
                  radius: 38,
                  backgroundImage: AssetImage('assets/images/images.png'),
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            //interactive chart
          ],
        ),
      ),
    );
  }
}
