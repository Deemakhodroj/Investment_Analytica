package com.example.investment_analatyca_testthree

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
